export class CLog {

    
}
