export class CLog {

    
}
